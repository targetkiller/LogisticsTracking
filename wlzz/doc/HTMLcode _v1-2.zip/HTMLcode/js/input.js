function onFocus (obj) {
	// body...
	obj.style.borderColor="#468ee3";
	obj.style.borderWidth="2px";
}
function onBlur(obj) {
	// body...
	obj.style.borderColor="#afafaf";
	obj.style.borderWidth="1px";
}