function onFocus (obj,text) {
	// body...
	obj.style.borderColor="#468ee3";
	obj.style.borderWidth="2px";
	var element=document.getElementById(text);
	element.style.display="inline";
}
function onBlur(obj,text) {
	// body...
	obj.style.borderColor="#afafaf";
	obj.style.borderWidth="1px";
	var element=document.getElementById(text);
	element.style.display="none";
}
function verification(){
	var nicknameinput=document.getElementById("nicknameinput");
	var mailinput=document.getElementById("mailinput");
	var ageinput=document.getElementById("ageinput");
	var phoneinput=document.getElementById("phoneinput");
	var zipcodeinput=document.getElementById("zipcodeinput");
	var addressinput=document.getElementById("addressinput");
	var tips=document.getElementById("tips");
	if(nicknameinput.value==""){
		tips.style.display="inline";
		tips.setAttribute("for","nicknameinput");
		return;
	}
	else if(mailinput.value==""){
		tips.style.display="inline";
		tips.setAttribute("for","mailinput");
		return;
	}
	else if(ageinput.value==""){
		tips.style.display="inline";
		tips.setAttribute("for","ageinput");
		return;
	}
	else if(phoneinput.value==""){
		tips.style.display="inline";
		tips.setAttribute("for","phoneinput");
		return;
	}
	else if(zipcodeinput.value==""){
		tips.style.display="inline";
		tips.setAttribute("for","zipcodeinput");
		return;
	}
	else if(addressinput.value==""){
		tips.style.display="inline";
		tips.setAttribute("for","addressinput");
		return;
	}
	else{
		tips.style.display="none";
	}
}